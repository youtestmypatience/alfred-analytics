# Alfred Analytics — Antifraud Knowledge Base

Готовый статический сайт, собранный из Markdown-заметок Obsidian.

## Состав
- 21 основных модулей
- 2174 подразделов
- 34 таблиц
- 184 внешних ссылок на источники
- 84,758 слов

## Локальный запуск
Из папки сайта:

```bash
python -m http.server 8000
```

Затем открыть `http://localhost:8000`.

## Публикация
Папку можно разместить как статический сайт на GitHub Pages, Cloudflare Pages, Netlify или Vercel без сборки. Корневая страница — `index.html`.
